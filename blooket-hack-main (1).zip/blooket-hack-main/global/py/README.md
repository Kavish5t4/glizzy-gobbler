# py

This Python script adds tokens and xp to your account every day.

- Install the latest Python release from https://www.python.org/downloads/
- Open addTokensDaily.py and change the first to variables to your username/email and password.
- In your command line type navigate to this working directory
- type `python3 -m pip3 -r requirements.txt`. Alternatively, you can manually install the requirements listed in requirements.txt.
- type `python3 addTokensDaily.py`

