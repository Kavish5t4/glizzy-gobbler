# gold

This cheat only works in gold game mode!

# chest-ESP.js

### Get the script from the file [chest-ESP.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/gold/chest-ESP.js)

New scripts are at:
https://schoolcheats.net/blooket

# getGold.js

### Get the script from the file [getGold.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/gold/getGold.js)

New scripts are at:
https://schoolcheats.net/blooket
