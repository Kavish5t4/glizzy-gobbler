# racing 

This cheat only works in racing game mode!

# instantWin.js

### Get the script from the file [instantWin.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/racing/instantWin.js)

New scripts are at:
https://schoolcheats.net/blooket
