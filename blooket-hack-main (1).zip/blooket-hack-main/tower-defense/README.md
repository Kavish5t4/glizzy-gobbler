# tower-defense

This cheat only works in tower defense game mode!

# changeGameRound.js

### Get the script from the file [changeGameRound.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/changeGameRound.js)

New scripts are at:
https://schoolcheats.net/blooket


# clearEnemies.js

### Get the script from the file [clearEnemies.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/clearEnemies.js)

New scripts are at:
https://schoolcheats.net/blooket


# getCash.js

### Get the script from the file [getCash.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/getCash.js)

New scripts are at:
https://schoolcheats.net/blooket
