# factory

This cheat only works in factory game mode!

# getCash.js

### Get the script from the file [getCash.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/factory/getCash.js)

New scripts are at:
https://schoolcheats.net/blooket

# getMegaBot.js

### Get the script from the file [getMegaBot.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/factory/getMegaBot.js)

New scripts are at:
https://schoolcheats.net/blooket
