# crazy-kingdom

This cheat only works in crazy kingdom gamemode!

# ChoiceESP.js

### Get the script from the file [ChoiceESP.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/ChoiceESP.js)

New scripts are at:
https://schoolcheats.net/blooket

# MaxResources.js

### Get the script from the file [MaxResources.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/MaxResources.js)

New scripts are at:
https://schoolcheats.net/blooket

# NoTaxes.js

### Get the script from the file [NoTaxes.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/NoTaxes.js)

New scripts are at:
https://schoolcheats.net/blooket

# SetGuests.js

### Get the script from the file [SetGuests.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/SetGuests.js)

New scripts are at:
https://schoolcheats.net/blooket

# SkipGuests.js

### Get the script from the file [SkipGuests.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/SkipGuests.js)

New scripts are at:
https://schoolcheats.net/blooket
